// King's World multiplayer server: serves the game and syncs players over WebSocket.
const http = require('http'), fs = require('fs'), path = require('path');
const { WebSocketServer } = require('ws');

const PORT = process.env.PORT || 3000;
const DATA = process.env.DATA_FILE || path.join(__dirname, 'data.json');
let scores = {};
try { scores = JSON.parse(fs.readFileSync(DATA, 'utf8')); } catch (e) {}
let dirty = false;

const server = http.createServer((req, res) => {
  if (req.url === '/health') { res.end('ok'); return; }
  if (req.url === '/' || req.url === '/index.html' || req.url.startsWith('/?')) {
    fs.readFile(path.join(__dirname, 'public', 'index.html'), (e, d) => {
      if (e) { res.writeHead(404); res.end('Game file missing'); return; }
      res.writeHead(200, { 'Content-Type': 'text/html; charset=utf-8' });
      res.end(d);
    });
    return;
  }
  res.writeHead(404); res.end('Not found');
});

const wss = new WebSocketServer({ server, maxPayload: 1024 });
const clients = new Map();
const NAME_RE = /^[A-Za-z]{3,10} [A-Za-z]{3,10} \d{1,2}$/;
const ID_RE = /^[a-z0-9]{8,24}$/;
const EMOTES = 4;

function board() {
  return Object.keys(scores)
    .map(id => ({ id, name: scores[id].name, pts: scores[id].pts }))
    .sort((a, b) => b.pts - a.pts).slice(0, 15);
}
function send(ws, obj) { if (ws.readyState === 1) ws.send(JSON.stringify(obj)); }

wss.on('connection', ws => {
  const st = { id: null, name: '', x: 60, e: '🚶', win: Date.now(), rate: 0, gw: 0, gain: 0, alive: true };
  clients.set(ws, st);
  ws.on('pong', () => { st.alive = true; });
  ws.on('message', raw => {
    const now = Date.now();
    if (now - st.win > 1000) { st.win = now; st.rate = 0; }
    if (++st.rate > 40) return;
    let m; try { m = JSON.parse(raw); } catch (e) { return; }
    if (!m || typeof m.t !== 'string') return;
    if (m.t === 'hello') {
      if (st.id || typeof m.id !== 'string' || !ID_RE.test(m.id)) return;
      st.id = m.id;
      st.name = NAME_RE.test(String(m.name || '')) ? m.name : 'Royal Guest ' + (1 + Math.floor(Math.random() * 99));
      send(ws, { t: 'board', list: board() });
      return;
    }
    if (!st.id) return;
    if (m.t === 'pos') {
      if (typeof m.x === 'number' && isFinite(m.x)) st.x = Math.max(0, Math.min(10000, m.x));
      if (typeof m.e === 'string' && m.e.length <= 8) st.e = m.e;
    } else if (m.t === 'score') {
      const p = Math.floor(m.pts);
      if (!(p >= 0 && p <= 1e6)) return;
      const old = scores[st.id];
      const prev = old ? old.pts : 0;
      if (p > prev) {
        if (!old && p > 20000) return;
        if (old) {
          if (now - st.gw > 60000) { st.gw = now; st.gain = 0; }
          if (st.gain + (p - prev) > 2500) return;
          st.gain += p - prev;
        }
      }
      scores[st.id] = { name: st.name, pts: p, t: now };
      dirty = true;
    } else if (m.t === 'emote') {
      const k = m.k | 0;
      if (k >= 0 && k < EMOTES) {
        const msg = JSON.stringify({ t: 'emote', id: st.id, k });
        for (const c of wss.clients) if (c.readyState === 1) c.send(msg);
      }
    }
  });
  ws.on('close', () => clients.delete(ws));
  ws.on('error', () => {});
});

setInterval(() => {
  const all = [...clients.entries()].filter(([, s]) => s.id);
  if (!all.length) return;
  for (const [ws, me] of all) {
    const list = all.filter(([w]) => w !== ws)
      .map(([, s]) => ({ id: s.id, n: s.name, x: Math.round(s.x), e: s.e }))
      .sort((a, b) => Math.abs(a.x - me.x) - Math.abs(b.x - me.x)).slice(0, 40);
    send(ws, { t: 'players', list, count: all.length });
  }
}, 125);

setInterval(() => {
  const msg = JSON.stringify({ t: 'board', list: board() });
  for (const [ws, s] of clients) if (s.id && ws.readyState === 1) ws.send(msg);
}, 4000);

setInterval(() => {
  for (const [ws, s] of clients) { if (!s.alive) { ws.terminate(); continue; } s.alive = false; try { ws.ping(); } catch (e) {} }
}, 30000);

function save() {
  if (!dirty) return;
  const keep = Object.keys(scores).sort((a, b) => scores[b].pts - scores[a].pts).slice(0, 5000);
  const out = {}; keep.forEach(k => out[k] = scores[k]); scores = out;
  try { fs.writeFileSync(DATA, JSON.stringify(scores)); dirty = false; } catch (e) {}
}
setInterval(save, 20000);
process.on('SIGTERM', () => { save(); process.exit(0); });
process.on('SIGINT', () => { save(); process.exit(0); });

server.listen(PORT, () => console.log('King\u2019s World server on port ' + PORT));
